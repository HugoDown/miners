#!/usr/bin/env bash
set -x
#conf="$CUSTOM_USER_CONFIG"

#
# Doing some magic here
#
# Example configuration
##CUSTOM_USER_CONFIG='-t $(nproc --ignore=1) -i SUVSIJWDQURNJCAFVNRBUQNDOKGAGKOJYUAEINDKEFKPCMQPQDCUMFMBCQSJ --label cpu-3900x-5'

# Extract the dynamic part (assuming 'nproc' command is your dynamic part)
DYNAMIC_PART=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '\$\((nproc.*)\)')

# Check if the dynamic part was successfully extracted
if [ ! -z "$DYNAMIC_PART" ]; then
    # Evaluate the dynamic part to get its actual value
    EVALUATED_DYNAMIC_PART=$(eval echo "$DYNAMIC_PART")
    
    # Substitute the evaluated part back into the configuration
    # This step replaces the original dynamic command with its evaluated output
    # First, prepare a version of DYNAMIC_PART that is safe for use in sed
    SAFE_DYNAMIC_PART=$(printf '%s\n' "$DYNAMIC_PART" | sed 's:[][\/.^$*]:\\&:g')
    
    # Now, replace the dynamic part with its evaluated output
    MODIFIED_CONFIG=$(echo "$CUSTOM_USER_CONFIG" | sed "s/$SAFE_DYNAMIC_PART/$EVALUATED_DYNAMIC_PART/")
    
    # Output the modified configuration
    echo "Modified config: $MODIFIED_CONFIG"
conf="$MODIFIED_CONFIG"
else
    echo "No dynamic part found. No modifications made."
conf="$CUSTOM_USER_CONFIG"
fi


echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

echo "wrote config to $CUSTOM_CONFIG_FILENAME"
echo "The contents of the config file are: $(<$CUSTOM_CONFIG_FILENAME)"
